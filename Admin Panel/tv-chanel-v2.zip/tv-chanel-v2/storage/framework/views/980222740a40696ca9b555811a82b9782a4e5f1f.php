 



 <?php $__env->startSection('content'); ?>

 <h2>Notifications</h2>
 <div class="card-body">
     <table id="example2" class="table table-bordered table-hover">
         <thead>
             <tr class="table-header">
                 <th scope=" col"><i class="fas fa-sort"></i></th>
                 <th>message</th>
                 <th>url </th>
                 <th>image</th>
                 <th>actions</th>


             </tr>
         </thead>
         <tbody>
             <?php $i = ($notifications->currentpage() - 1) * $notifications->perpage();
                $i = $i + 1;
                ?>
             <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
                 <th scope="row"><?php echo e($i++); ?></th>
                 <td><?php echo e($notification->message); ?></td>
                 <td><?php echo e($notification->url); ?></td>
                 <td><img src="<?php echo e(asset( $notification->image)); ?>" alt="image not found"></td>

                 <td>
                     <div class="" role="group" aria-label="Basic example">
                         <i class="fas fa-edit"></i>
                         <a href="delnotification/<?php echo e($notification->id); ?>">
                             <i class="fas fa-trash-alt" style="margin-left:20px"></i>
                         </a>

                     </div>
                 </td>


             </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


         </tbody>

     </table>
     <?php echo e($notifications->links()); ?>

 </div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dgubstation\laravel-admin2\resources\views/layouts/notification/index.blade.php ENDPATH**/ ?>