 



 <?php $__env->startSection('content'); ?>

 <div class="container fluid">
     <div class="card">


         <form method="post" action="<?php echo e(route('storecatagory')); ?>" enctype="multipart/form-data" style="margin:4rem;">
             <?php echo e(csrf_field()); ?>

             <div class="form-group">
                 <label for="formGroupExampleInput1">Category Name</label>
                 <input type="text" class="form-control" id="formGroupExampleInput1" placeholder=" name" name="name">
             </div>
             <div class="form-group">

                 <div class="row">
                     <div class="col"><label for="formGroupExampleInput2">Category Type</label>
                         <select id="" name="category_type">
                             <option value="0" selected>Locked</option>
                             <option value="1">Unlocked</option>



                         </select>
                     </div>
                     <div class="col"> <label for="formGroupExampleInput3">Pass</label>
                         <input type="text" class="form-control w-75" id="formGroupExampleInput3" placeholder="pass" name="pass">
                     </div>
                 </div>



             </div>


             <div class="form-group">
                 <label for="formGroupExampleInput3">Preview Image</label>
                 <input type="file" name="image" class="form-control">
             </div>
             <div class="form-group float-right">
                 <button type="submit" class="btn btn-info">Add Category</button>
             </div>

         </form>
     </div>
 </div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dgubstation\live-tv\resources\views/layouts/category/add.blade.php ENDPATH**/ ?>