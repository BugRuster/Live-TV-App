 



 <?php $__env->startSection('content'); ?>

 <div class="product-form">

     <form method="post" action="<?php echo e(route('storeproduct')); ?>" enctype="multipart/form-data">
         <?php echo e(csrf_field()); ?>

         <div class="form-group">
             <label for="formGroupExampleInput1">name</label>
             <input type="text" class="form-control" id="formGroupExampleInput1" placeholder=" name" name="name">
         </div>


         <div class="form-group">
             <label for="formGroupExampleInput3">image</label>
             <input type="file" name="image" class="form-control">
         </div>

         <div class=" form-group">
             <label for="1">category</label>
             <select class="form-control" name="cat_id" id="1">
                 <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             </select>
         </div>

         <div class="form-group">
             <label for="formGroupExampleInput1">url</label>
             <input type="text" class="form-control" id="formGroupExampleInput1" placeholder="url" name="url">
         </div>
         <div class="form-group">
             <label for="formGroupExampleInput1">url type</label>
             <input type="text" class="form-control" id="formGroupExampleInput1" placeholder=" url_type" name="url_type">
         </div>
         <div class="form-group">
             <label for="formGroupExampleInput1">useragent</label>
             <input type="text" class="form-control" id="formGroupExampleInput1" placeholder=" user_agent" name="user_agent">
         </div>
         <div class="form-group">
             <label for="formGroupExampleInput1">token</label>
             <input type="text" class="form-control" id="formGroupExampleInput1" placeholder=" token" name="token">
         </div>
         <div class="form-group">
             <label for="formGroupExampleInput1">extra</label>
             <input type="text" class="form-control" id="formGroupExampleInput1" placeholder=" naextrame" name="extra">
         </div>


         <!-- /.card-header -->
         <div class="form-group">
             <label for="formGroupExampleInput1">description</label>
             <textarea id="summernote" name="description" placeholder="description">

              </textarea>

         </div>
         <!-- /.col-->
 </div>
 <!-- /.col-->


 <div class="form-group">
     <button type="submit" class="btn btn-info">add product</button>
 </div>

 </form>
 </div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dgubstation\laravel-admin2\resources\views/layouts/products/create.blade.php ENDPATH**/ ?>