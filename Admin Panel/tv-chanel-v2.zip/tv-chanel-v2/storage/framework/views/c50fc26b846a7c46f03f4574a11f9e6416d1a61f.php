 



 <?php $__env->startSection('content'); ?>

 <div class="slider-from">

     <form method="post" action="<?php echo e(route('slider.store')); ?>" enctype="multipart/form-data">
         <?php echo e(csrf_field()); ?>

         <div class="form-group">
             <label for="formGroupExampleInput1">name</label>
             <input type="text" class="form-control" id="formGroupExampleInput1" placeholder="name" name="name" requireds>
         </div>
         <div class="form-group">
             <label for="formGroupExampleInput3">product</label>
             <select class="form-control" name="product_id">
                 <?php $__currentLoopData = App\Product::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>

                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </select>
         </div>

         <div class="form-group">
             <label for="formGroupExampleInput3">image</label>
             <input type="file" name="image" class="form-control">
         </div>
         <div class="form-group">
             <button type="submit" class="btn btn-info">add slider</button>
         </div>

     </form>
 </div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dgubstation\laravel-admin2\resources\views/layouts/sliders/create.blade.php ENDPATH**/ ?>