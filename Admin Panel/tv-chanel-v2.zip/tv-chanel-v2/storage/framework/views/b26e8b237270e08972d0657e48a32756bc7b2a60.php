 



 <?php $__env->startSection('content'); ?>
 <div class="card">
     <div class="card-header">
         <h3 class="card-title">Categories</h3>

         <div class="card-tools">


             <a href="<?php echo e(route('category.create')); ?>">
                 <button type="button" class="btn btn-create">Add new category</button>
             </a>


         </div>
     </div>

     <div class="content-table">
         <div class="card-body" id="app">
             <div style="overflow-x:auto;">
                 <table id="example" class="table table-striped">
                     <thead>
                         <tr class="table-header">
                             <th scope=" col"><i class="fas fa-sort"></i></th>
                             <th>Name</th>
                             <th>Category Type</th>
                             <th class="hide"> Image </th>

                             <th>Actions</th>


                         </tr>
                     </thead>
                     <tbody>
                         <?php $i = ($categories->currentpage() - 1) * $categories->perpage();
                            $i = $i + 1;
                            ?>
                         <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                             <th scope="row"><?php echo e($i++); ?></th>
                             <td><?php echo e($category->name); ?></td>

                             <td>
                                 <?php if($category->category_type==0): ?>
                                 Locked
                                 <?php else: ?>
                                 Unlocked
                                 <?php endif; ?>
                             </td>
                             <td class="hide">
                                 <div class="table-img">
                                     <img src=" <?php echo e(asset( $category->image)); ?>" alt="image not found" width="200" height="300">
                                 </div>
                             </td>




                             <td>
                                 <div class="" role="group" aria-label="Basic example" style="display:flex;">
                                     <a href="editcategory/<?php echo e($category->id); ?>" class="btn btn-light" role="button">
                                         <i class="fas fa-edit"></i>
                                     </a>
                                     <a href="delcategory/<?php echo e($category->id); ?>" class="btn btn-light" role="button" onclick="return confirm('Are you sure you want to delete this item')">
                                         <i class="fas fa-trash-alt" style=""></i>
                                     </a>

                                 </div>
                                 <div style="margin:1rem">
                                     <modal-el showing="exampleModalShowing" :item="<?php echo e($category); ?>" type="category" size="lg" />
                                 </div>
                             </td>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                     </tbody>

                 </table>
             </div>

             <div style="margin-left:500px">
                 <?php echo e($categories->links()); ?>

             </div>
         </div>
     </div>
 </div>
 <!-- <script src="<?php echo e(asset('js/app.js')); ?>"></script> -->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dgubstation\live-tv\resources\views/layouts/category/index.blade.php ENDPATH**/ ?>