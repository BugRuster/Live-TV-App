 



 <?php $__env->startSection('content'); ?>
 <div class="content-header">
     <h2>Sliders</h2>
     <div class="create-new-btn">
         <a href="<?php echo e(route('slider.create')); ?>">
             <button type="button" class="btn btn-create">add slider</button>
         </a>
     </div>
 </div>
 <div class="content-table">
     <div class="card-body">
         <table id="example1" class="table table-bordered table-hover">
             <thead>
                 <tr class="table-header">
                     <th scope="col"><i class="fas fa-sort"></i></th>
                     <th>name</th>
                     <th>product</th>
                     <th>image</th>
                     <th>actions</th>
                 </tr>
             </thead>
             <tbody>
                 <?php $i = ($sliders->currentpage() - 1) * $sliders->perpage();
                    $i = $i + 1;
                    ?>
                 <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                     <th scope="row"><?php echo e($i++); ?></th>
                     <td><?php echo e($slider->name); ?></td>
                     <td><?php echo e($slider->product->name); ?></td>
                     <td>
                         <img src="<?php echo e(asset($slider->image)); ?>" alt="image not found" width="100" height="100">
                     </td>

                     <td>
                         <div class="" role="group" aria-label="Basic example">
                             <i class="fas fa-edit"></i>
                             <a href="delslider/<?php echo e($slider->id); ?>">
                                 <i class="fas fa-trash-alt" style="margin-left:20px"></i>
                             </a>

                         </div>
                     </td>



                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


             </tbody>

         </table>
         <div style="margin-left:500px">
             <?php echo e($sliders->links()); ?>

         </div>
     </div>
 </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dgubstation\laravel-admin2\resources\views/layouts/sliders/index.blade.php ENDPATH**/ ?>