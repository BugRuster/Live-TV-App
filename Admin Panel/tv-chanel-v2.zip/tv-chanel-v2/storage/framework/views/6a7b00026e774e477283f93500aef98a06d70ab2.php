 



 <?php $__env->startSection('content'); ?>

 <section class="content">
     <div class="container-fluid">
         <div class="row">
             <div class="col-12">
                 <div class="card">

                     <!-- /.card-header -->

                     <div class="card-header">
                         <h3 class="card-title">Notofocation</h3>

                         <div class="card-tools">


                             <a href="<?php echo e(route('notification.create')); ?>">
                                 <button type="button" class="btn btn-create">Send Notification</button></a>



                         </div>
                     </div>
                     <div class="card-body" id="app">
                         <div style="overflow-x:auto;">
                             <table id="example" class="table table-bordered table-hover">
                                 <thead>
                                     <tr class="table-header">
                                         <th scope=" col"><i class="fas fa-sort"></i></th>
					<th>Title</th>
                                         <th>Messages</th>
                                         <th>Url</th>
                                         <th>Image</th>
                                         <th>Actions</th>


                                     </tr>
                                 </thead>
                                 <tbody>
                                     <?php $i = ($notifications->currentpage() - 1) * $notifications->perpage();
                                        $i = $i + 1;
                                        ?>
                                     <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <tr>
                                         <th scope="row"><?php echo e($i++); ?></th>
					<td><?php echo e($notification->title); ?></td>
                                         <td><?php echo e($notification->message); ?></td>
                                         <td>
                                             <a href=" <?php echo e($notification->url); ?>">
                                                 <?php echo e($notification->url); ?>

                                             </a>

                                         </td>
                                         <td><img src="<?php echo e(asset( $notification->image)); ?>" alt="image not found" width="100" height="100"></td>

                                         <td>
                                             <div class="" role="group" aria-label="Basic example" style="display:flex;">


                                                 <a href="delnotification/<?php echo e($notification->id); ?>" class="btn btn-light" role="button" onclick="return confirm('Are you sure you want to delete this item')">
                                                     <i class="fas fa-trash-alt" style=""></i>
                                                 </a>
                                                 <div style="margin-left:2rem">
                                                     <modal-notification :item="<?php echo e($notification); ?>" size="lg" />
                                                 </div>

                                             </div>
                                         </td>


                                     </tr>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                 </tbody>

                             </table>
                             <?php echo e($notifications->links()); ?>

                         </div>


                     </div>
                 </div>
             </div>
         </div>
     </div>
 </section>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/abir/tv-chanel/resources/views/layouts/notification/index.blade.php ENDPATH**/ ?>