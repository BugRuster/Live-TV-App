 



 <?php $__env->startSection('content'); ?>



 <div class="col-md-10" style="margin-left:40px">
     <div class="card card-primary">
         <div class="card-header">
             <h3 class="card-title">Add user</h3>

             <div class="card-tools">
                 <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                     <i class="fas fa-minus"></i>
                 </button>
             </div>
         </div>
         <form method="post" action="<?php echo e(route('administration.store')); ?>" enctype="multipart/form-data">
             <?php echo e(csrf_field()); ?>


             <div class="card-body">
                 <div class="form-group">
                     <label for="inputName">user Name</label>
                     <input type="text" id="inputName" class="form-control" name="name">
                 </div>
                 <div class="form-group">
                     <label for="inputName">email </label>
                     <input type="email" id="inputName" class="form-control" name="email">
                 </div>
                 <div class="form-group">
                     <label for="inputName">password </label>
                     <input type="password" id="inputName" class="form-control" name="password">
                 </div>

                 <div class="form-group">
                     <label for="role">role</label>
                     <select class="form-control" name="role" id="role">
                         <?php $__currentLoopData = App\Role::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     </select>
                 </div>

                 <div class="form-group">
                     <button type="submit" class="btn btn-info">add user</button>
                 </div>
             </div>
         </form>


         <!-- /.card-body -->
     </div>
     <!-- /.card -->

 </div>


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dgubstation\laravel-admin2\resources\views/layouts/administration/addUser.blade.php ENDPATH**/ ?>