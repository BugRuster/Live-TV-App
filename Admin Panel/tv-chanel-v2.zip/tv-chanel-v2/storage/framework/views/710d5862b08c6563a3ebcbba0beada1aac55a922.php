 



 <?php $__env->startSection('content'); ?>


 <div class="content-header">
     <h2>chanels</h2>
     <div class="create-new-btn">
         <a href="<?php echo e(route('addproduct')); ?>">
             <button type="button" class="btn btn-create">add chanels</button></a>
     </div>
 </div>






 <div class="content-table">
     <div class="card-body">
         <table id="example1" class="table table-bordered">
             <thead>
                 <tr class="table-header">
                     <th scope="col"><i class="fas fa-sort"></i></th>
                     <th>name</th>
                     <th>category</th>
                     <th>image</th>

                     <th>description</th>
                     <th>url</th>
                     <th>url_type</th>
                     <th>action</th>
                 </tr>
             </thead>
             <tbody>
                 <?php $i = ($products->currentpage() - 1) * $products->perpage();
                    $i = $i + 1;
                    ?>
                 <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                 <tr>
                     <td><?php echo e($i++); ?></td>
                     <td><?php echo e($product->name); ?></td>
                     <td><?php echo e($product->category->name); ?></td>
                     <td>
                         <img src=" <?php echo e(asset($product->image)); ?>" alt="image not found" width="100" height="100">

                     </td>
                     <td><?php echo e($product->description); ?></td>
                     <td><?php echo e($product->url); ?></td>
                     <td><?php echo e($product->url_type); ?></td>
                     <td>
                         <div class="" role="group" aria-label="Basic example">

                             <a href="editproduct/<?php echo e($product->id); ?>">
                                 <i class="fas fa-edit"></i>
                             </a>

                             <a href="delproduct/<?php echo e($product->id); ?>">
                                 <i class="fas fa-trash-alt" style="margin-left:20px"></i>
                             </a>
                         </div>
                     </td>



                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             </tbody>

         </table>
         <div style="margin-left:500px">
             <?php echo e($products->links()); ?>

         </div>

     </div>
 </div>
 <!-- <div>
     <div class="card">
         <div class="card-header">
             <h3 class="card-title">DataTable with minimal features & hover style</h3>
         </div>
          
         <div class="card-body">
             <table id="example2" class="table table-bordered table-hover">
                 <thead>
                     <tr>
                         <th scope="col"></th>
                         <th>name</th>
                         <th>category</th>
                         <th>image</th>

                         <th>description</th>
                         <th>url</th>
                         <th>url_type</th>
                         <th>action</th>
                     </tr>
                 </thead>
                 <tbody>
                     <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                         <th scope="row"><?php echo e($key+1); ?></th>
         <td><?php echo e($product->name); ?></td>
         <td><?php echo e($product->category->name); ?></td>
         <td>
             <img src=" <?php echo e(asset($product->image)); ?>" alt="image" width="100" height="100">

         </td>
         <td><?php echo e($product->description); ?></td>
         <td><?php echo e($product->url); ?></td>
         <td><?php echo e($product->url_type); ?></td>
         <td>
             <div class="" role="group" aria-label="Basic example">

                 <a href="editproduct/<?php echo e($product->id); ?>">
                     <i class="fas fa-edit"></i>
                 </a>

                 <a href="delproduct/<?php echo e($product->id); ?>">
                     <i class="fas fa-trash-alt" style="margin-left:20px"></i>
                 </a>
             </div>
         </td>



         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

         </tbody>
         <tfoot>
             <tr>
                 <th>Rendering engine</th>
                 <th>Browser</th>
                 <th>Platform(s)</th>
                 <th>Engine version</th>
                 <th>CSS grade</th>
             </tr>
         </tfoot>
     </table>
 </div>

 </div>
 </div> -->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dgubstation\laravel-admin2\resources\views/layouts/products/index.blade.php ENDPATH**/ ?>