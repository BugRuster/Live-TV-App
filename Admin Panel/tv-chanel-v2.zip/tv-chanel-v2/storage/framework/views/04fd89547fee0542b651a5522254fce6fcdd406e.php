 



 <?php $__env->startSection('content'); ?>
 <div class="container fluid" style="overflow-x:auto;">
     <div class="card">


         <form method="post" action="<?php echo e(route('slider.store')); ?>" enctype="multipart/form-data" style="margin:3rem;">
             <?php echo e(csrf_field()); ?>

             <div class="form-group">
                 <label for="formGroupExampleInput1">Name</label>
                 <input type="text" class="form-control" id="formGroupExampleInput1" placeholder="name" name="name" requireds>
             </div>
             <div class="row">
                 <div class="col">
                     <div class="form-group">
                         <label for="formGroupExampleInput3">Chanel</label>
                         <select class="form-control w-75" name="product_id">
                             <?php $__currentLoopData = App\Product::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>

                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </select>
                     </div>
                 </div>
                 <div class="col">
                     <div class="form-group">
                         <label for="formGroupExampleInput3">Preview Image</label>
                         <input type="file" name="image" class="form-control w-75">
                     </div>
                 </div>
             </div>



             <div class="form-group float-right" style="margin-top: 3rem">
                 <button type="submit" class="btn btn-info">Add Slider</button>
             </div>

         </form>
     </div>
 </div>
 </div>
 </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dgubstation\live-tv\resources\views/layouts/sliders/create.blade.php ENDPATH**/ ?>