 



 <?php $__env->startSection('content'); ?>

 <div class="category-from">

     <form method="post" action="<?php echo e(route('storecatagory')); ?>" enctype="multipart/form-data">
         <?php echo e(csrf_field()); ?>

         <div class="form-group">
             <label for="formGroupExampleInput1">name</label>
             <input type="text" class="form-control" id="formGroupExampleInput1" placeholder=" name" name="name">
         </div>
         <div class="form-group">
             <label for="formGroupExampleInput2">category type</label>
             <input type="text" class="form-control" id="formGroupExampleInput2" placeholder=" type" name="category_type">
         </div>
         <div class="form-group">
             <label for="formGroupExampleInput3">pass</label>
             <input type="text" class="form-control" id="formGroupExampleInput3" placeholder="pass" name="pass">
         </div>

         <div class="form-group">
             <label for="formGroupExampleInput3">image</label>
             <input type="file" name="image" class="form-control">
         </div>
         <div class="form-group">
             <button type="submit" class="btn btn-info">add category</button>
         </div>

     </form>
 </div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dgubstation\laravel-admin2\resources\views/layouts/category/add.blade.php ENDPATH**/ ?>