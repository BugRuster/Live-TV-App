 



 <?php $__env->startSection('content'); ?>
 <section class="content">
     <div class="container-fluid">
         <!-- Small boxes (Stat box) -->
         <h2 style="margin-bottom: 30px">Dashboard</h2>
         <div class="row">
             <div class="col-lg-3 col-6">
                 <!-- small box -->
                 <div class="small-box bg-info">
                     <div class="inner">
                         <h3><?php echo e($item_counts['category']); ?></h3>

                         <p>Categories</p>
                     </div>
                     <div class="icon">
                         <i class="fas fa-chevron-circle-down"></i>
                     </div>
                     <a href="<?php echo e(route('category.index')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                 </div>
             </div>
             <!-- ./col -->
             <div class="col-lg-3 col-6">
                 <!-- small box -->
                 <div class="small-box bg-success">
                     <div class="inner">

                         <h3><?php echo e($item_counts['product']); ?></h3>


                         <p>Channels</p>
                     </div>
                     <div class="icon">
                         <i class="fas fa-box"></i>
                     </div>
                     <a href="<?php echo e(route('product.index')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                 </div>
             </div>
             <!-- ./col -->
             <div class="col-lg-3 col-6">
                 <!-- small box -->
                 <div class="small-box bg-warning">
                     <div class="inner">
                         <h3><?php echo e($item_counts['slider']); ?></h3>
                         <p>Sliders</p>
                     </div>
                     <div class="icon">
                         <i class="fas fa-images"></i>
                     </div>
                     <a href="<?php echo e(route('slider.index')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                 </div>
             </div>
             <!-- ./col -->
             <div class="col-lg-3 col-6">
                 <!-- small box -->
                 <div class="small-box bg-danger">
                     <div class="inner">
                         <h3><?php echo e($item_counts['notification']); ?></h3>

                         <p>Notifications</p>
                     </div>
                     <div class="icon">
                         <i class="far fa-bell"></i>
                     </div>
                     <a href="<?php echo e(route('notification.index')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                 </div>
             </div>
         </div>
     </div>

 </section>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dbugstation\tv-chanel\resources\views/layouts/dashboard/index.blade.php ENDPATH**/ ?>