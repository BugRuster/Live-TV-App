 



 <?php $__env->startSection('content'); ?>

 <div class="content-header">
     <h2>Categories</h2>
     <div class="create-new-btn">
         <a href="<?php echo e(route('category.create')); ?>">
             <button type="button" class="btn btn-create">add category</button>
         </a>

     </div>
 </div>
 <div class="content-table">
     <div class="card-body">
         <table id="example1" class="table table-bordered table-hover">
             <thead>
                 <tr class="table-header">
                     <th scope=" col"><i class="fas fa-sort"></i></th>
                     <th>name</th>
                     <th>image </th>
                     <th>category_type</th>
                     <th>actions</th>


                 </tr>
             </thead>
             <tbody>
                 <?php $i = ($categories->currentpage() - 1) * $categories->perpage();
                    $i = $i + 1;
                    ?>
                 <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                     <th scope="row"><?php echo e($i++); ?></th>
                     <td><?php echo e($category->name); ?></td>
                     <td>

                         <img src=" <?php echo e(asset( $category->image)); ?>" alt="image not found" width="100" height="100">

                     </td>
                     <td><?php echo e($category->category_type); ?></td>



                     <td>
                         <div class="" role="group" aria-label="Basic example">
                             <i class="fas fa-edit"></i>
                             <a href="delcategory/<?php echo e($category->id); ?>">
                                 <i class="fas fa-trash-alt" style="margin-left:20px"></i>
                             </a>

                         </div>
                     </td>
                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


             </tbody>

         </table>
         <div style="margin-left:500px">
             <?php echo e($categories->links()); ?>

         </div>
     </div>
 </div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dgubstation\laravel-admin2\resources\views/layouts/category/index.blade.php ENDPATH**/ ?>