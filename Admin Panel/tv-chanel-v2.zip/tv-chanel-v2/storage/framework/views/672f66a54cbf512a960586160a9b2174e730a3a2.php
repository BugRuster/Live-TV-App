 



 <?php $__env->startSection('content'); ?>

 <div class="card">
     <div class="card-header">
         <h3 class="card-title">Administration</h3>

         <div class="card-tools">


             <a href="<?php echo e(route('administration.create')); ?>">
                 <button type="button" class="btn btn-info">Add new user</button>
             </a>


         </div>
     </div>
     <div class="card-body p-0">
         <table class="table table-striped projects">
             <thead>
                 <tr>
                     <th style="width: 1%">

                     </th>
                     <th style="width: 10%">
                         User Name
                     </th>
                     <th style="width: 6%">
                         Image
                     </th>
                     <th style="width: 5%">
                         Role
                     </th>
                     <th style="width: 8%">
                         Actions
                     </th>

                 </tr>
             </thead>
             <tbody>

                 <?php $i = ($users->currentpage() - 1) * $users->perpage();
                    $i = $i + 1;
                    ?>

                 <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                     <td>
                         <?php echo e($i++); ?>

                     </td>
                     <td>
                         <a>
                             <?php echo e($user->name); ?>

                         </a>
                         <br />
                         <small>
                             Created 01.01.2019
                         </small>
                     </td>
                     <td>
                         <ul class="list-inline">
                             <li class="list-inline-item">
                                 <img alt="Avatar" class="table-avatar" src="../../dist/img/avatar.png">
                             </li>

                         </ul>

                     </td>
                     <td>
                         <?php if( $user->role==1): ?>


                         <p>admin</p>


                         <?php else: ?>
                         <p>supervisor</p>

                         <?php endif; ?>
                     </td>

                     <td class="">


                         <a href="edituser/<?php echo e($user->id); ?>" class="btn btn-light" role="button">
                             <i class="fas fa-edit"></i> Edit
                         </a>



                         <a class="btn btn-danger btn-sm" href="deluser/<?php echo e($user->id); ?>" role="button" onclick="return confirm('Are you sure you want to delete this item')">
                             <i class="fas fa-trash">
                             </i>
                             Delete
                         </a>
                     </td>
                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
         </table>
         <?php echo e($users->links()); ?>

     </div>
     <!-- /.card-body -->
 </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dgubstation\live-tv\resources\views/layouts/administration/index.blade.php ENDPATH**/ ?>