 <!-- /.navbar -->
 <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <!-- Main Sidebar Container -->


 <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
     <!-- Content Header (Page header) -->
     <div class="content-header">
         <div class="container-fluid">
             <div class="row mb-2">
                 <div class="col-sm-6">
                     <!-- <h1 class="m-0">Dashboard</h1> -->
                 </div><!-- /.col -->
                 <div class="col-sm-6">
                     <!-- <ol class="breadcrumb float-sm-right">
                         <li class="breadcrumb-item"><a href="#">Home</a></li>
                         <li class="breadcrumb-item active">Dashboard v1</li>
                     </ol> -->
                 </div><!-- /.col -->
             </div><!-- /.row -->
         </div><!-- /.container-fluid -->
     </div>
     <!-- /.content-header -->

     <!-- Main content -->
     <main>
         <?php echo $__env->yieldContent('content'); ?>
         <!-- <script src="<?php echo e(asset('js/app.js')); ?>" type=""></script> -->

     </main>
     <!-- /.content -->
 </div>

 <!-- /.content-wrapper -->
 <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/abir/tv-chanel-v2/resources/views/adminlte/dashboard.blade.php ENDPATH**/ ?>