 



 <?php $__env->startSection('content'); ?>

 <!-- Main content -->
 <section class="section">
     <div class="section-body">
         <div class="row">
             <div class="col-12">
                 <div class=" card">

                     <!-- /.card-header -->

                     <div class="card-header">
                         <h3 class="card-title">Channels</h3>

                         <div class="card-tools">


                             <a href="<?php echo e(route('addproduct')); ?>">
                                 <button type="button" class="btn btn-create">Add new Channel</button></a>



                         </div>
                     </div>


                     <div class="card-body" id="app">

                         <div style="overflow-x:auto;">
                             <table id="example" class="table table-striped">
                                 <thead>
                                     <tr class="table-header">
                                         <th style="width: 1%"> </i></th>
                                         <th>Name</th>
                                         <th style="width: 8%">Category</th>
                                         <th class="hide" style="width: 25%">Image</th>
                                         <th class="hide">Url</th>
                                         <th class="hide">Url Type</th>
                                         <th>Actions</th>
                                     </tr>
                                 </thead>
                                 <tbody>

                                     <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                     <tr>
                                         <td><?php echo e(++$key); ?></td>
                                         <td><?php echo e($product->name); ?></td>
                                         <td><?php echo e($product->category->cat_name); ?></td>
                                         <td class="hide">
                                             <div class="table-img">
                                                 <img src="<?php echo e(asset($product->image)); ?>" alt="image not found" width="200" height="200">
                                             </div>

                                         </td>


                                         <td class="hide">
                                             <div class="table-link">
                                                 <a href="<?php echo e($product->url); ?>">
                                                     <?php echo e($product->url); ?>

                                                 </a>
                                             </div>


                                         </td>
                                         <td class="hide"><?php echo e($product->url_type->name); ?></td>
                                         <td>
                                             <div class="" role="group" aria-label="Basic example" style="display:flex;">

                                                 <a href="editproduct/<?php echo e($product->id); ?>" class="btn btn-light" role="button">
                                                     <i class="fas fa-edit"></i>
                                                 </a>

                                                 <a href="delproduct/<?php echo e($product->id); ?>" class="btn btn-light" role="button" onclick="return confirm('Are you sure you want to delete this item')">
                                                     <i class="fas fa-trash-alt" style="margin-left:20px"></i>
                                                 </a>

                                             </div>


                                             <modal-el showing="exampleModalShowing" :item="<?php echo e($product); ?>" type='product' size="xl" />

                                         </td>


                                     </tr>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                 </tbody>

                             </table>
                         </div>

                         <!-- <div style="margin-left:500px">
                            
                         </div> -->

                     </div>



                     <!-- /.card-body -->
                 </div>
                 <!-- /.card -->
             </div>
             <!-- /.col -->
         </div>
         <!-- /.row -->

         <!-- /.container-fluid -->
     </div>
 </section>
 <!-- /.content -->
 <!-- <script src="<?php echo e(asset('js/app.js')); ?>"></script> -->


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/abir/tv-chanel/resources/views/layouts/products/index.blade.php ENDPATH**/ ?>