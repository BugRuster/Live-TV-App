 



 <?php $__env->startSection('content'); ?>

 <div class="product-form">

     <form method="post" action="<?php echo e(route('product.update', $product)); ?>" enctype="multipart/form-data">
         <?php echo e(csrf_field()); ?>

         <?php echo method_field('PATCH'); ?>
         <div class="form-group">
             <label for="">name</label>
             <input type="text" class="form-control" id="" placeholder="name" name="name" value="<?php echo e($product->name); ?>">
         </div>

         <div class="row">
             <div class="col">
                 <div class="form-group">
                     <label for="">image</label>
                     <input type="file" name="image" class="form-control" value="<?php echo e($product->image); ?>">
                 </div>
             </div>
             <div class="col">
                 <img src=" <?php echo e(asset($product->image)); ?>" alt="image" width="100" height="100">
             </div>
         </div>


         <div class=" form-group">
             <label for="1">category</label>
             <select class="form-control" name="cat_id" id="1">
                 <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             </select>
         </div>

         <div class="form-group">
             <label for="">url</label>
             <input type="text" class="form-control" id="" placeholder="url" name="url" value="<?php echo e($product->url); ?>">
         </div>
         <div class=" form-group">
             <label for="">url type</label>
             <input type="text" class="form-control" id="" placeholder=" url_type" name="url_type" value="<?php echo e($product->url_type); ?>">
         </div>
         <div class=" form-group">
             <label for="">useragent</label>
             <input type="text" class="form-control" id="" placeholder=" user_agent" name="user_agent" value="<?php echo e($product->user_agent); ?>">
         </div>
         <div class=" form-group">
             <label for="">token</label>
             <input type="text" class="form-control" id="" placeholder=" token" name="token" value="<?php echo e($product->token); ?>">
         </div>
         <div class=" form-group">
             <label for="">extra</label>
             <input type="text" class="form-control" id="" placeholder=" naextrame" name="extra" value="<?php echo e($product->extra); ?>">
         </div>


         <!-- /.card-header -->
         <div class=" form-group">
             <label for="">description</label>
             <textarea id="summernote" name="description" placeholder="description" value="<?php echo e($product->description); ?>">

              </textarea>

         </div>
         <!-- /.col-->

         <!-- /.col-->

         <div class="form-group">
             <button type="submit" class="btn btn-info">update product</button>
         </div>


     </form>
 </div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\dgubstation\laravel-admin2\resources\views/layouts/products/edit.blade.php ENDPATH**/ ?>