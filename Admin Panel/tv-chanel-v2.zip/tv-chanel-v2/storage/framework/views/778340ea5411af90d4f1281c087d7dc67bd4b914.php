 



 <?php $__env->startSection('content'); ?>

 <div class="container fluid">
     <div class="card">

         <form method="post" action="<?php echo e(route('product.update', $product)); ?>" enctype="multipart/form-data" style="margin:3rem;">
             <?php echo e(csrf_field()); ?>

             <?php echo method_field('PATCH'); ?>
             <div class="form-group">
                 <label for="">name</label>
                 <input type="text" class="form-control" id="namebox" placeholder="name" name="name" value="<?php echo e($product->name); ?>">
             </div>

             <div class="row">
                 <div class="col">
                     <div class="form-group">
                         <label for="">image</label>
                         <input type="file" name="image" class="form-control" value="<?php echo e($product->image); ?>" >
                     </div>
                 </div>
                 <div class="col">
                     <img src=" <?php echo e(asset($product->image)); ?>" alt="image" width="100" height="100">
                 </div>
             </div>


             <div class=" form-group">
                 <label for="1">category</label>
                 <select class="form-control" name="cat_id" id="catSelectbox">
                     <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                     <?php if($product->cat_id==$cat->id): ?>
                     <option value="<?php echo e($cat->id); ?>" selected> <?php echo e($cat->cat_name); ?> </option>
                     <?php else: ?>
                     <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->cat_name); ?></option>
                     <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                 </select>
             </div>

             <div class="form-group">
                 <label for="">url</label>
                 <input type="text" class="form-control" id="urlbox" placeholder="url" name="url" value="<?php echo e($product->url); ?>">
             </div>
             <div class=" form-group">
                 <label for="">url type</label>

                 <select class="form-control" name="url_id" id="urlSelectbox">
                     <?php $__currentLoopData = App\Url_type::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                     <?php if($product->url_id==$url->id): ?>
                     <option value="<?php echo e($url->id); ?>" selected> <?php echo e($url->name); ?> </option>
                     <?php else: ?>
                     <option value="<?php echo e($url->id); ?>"><?php echo e($url->name); ?></option>
                     <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                 </select>
             </div>
             <div class=" form-group">
                 <label for="">useragent</label>
                 <input type="text" class="form-control" id="" placeholder=" user_agent" name="user_agent" value="<?php echo e($product->user_agent); ?>">
             </div>
             <div class=" form-group">
                 <label for="">token</label>
                 <input type="text" class="form-control" id="" placeholder=" token" name="token" value="<?php echo e($product->token); ?>">
             </div>
             <div class=" form-group">
                 <label for="">extra</label>
                 <input type="text" class="form-control" id="" placeholder=" naextrame" name="extra" value="<?php echo e($product->extra); ?>">
             </div>


             <!-- /.card-header -->
             <div class=" form-group">
                 <label for="">description</label>
                 <textarea id="summernote" name="description" placeholder="description">
                 <?php echo e($product->description); ?>

                 </textarea>

             </div>
             <!-- /.col-->

             <!-- /.col-->

             <div class="form-group float-right">
                 <button type="submit" class="btn btn-info" onclick="return Validate()">update Channel</button>
             </div>


         </form>
     </div>
 </div>

 <script type="text/javascript">
     function Validate() {
         var nameVal = document.getElementById("namebox").value;
         var catSelectVal = document.getElementById("catSelectbox").value;
         var urlSelectVal = document.getElementById("urlSelectbox").value;
         var urlVal = document.getElementById("urlbox").value;
         if (nameVal == "") {
             alert('category name is needed');
             return false;
         }

         if (catSelectVal == '#') {
             alert('category  is needed');
             return false;
         }

         if (urlSelectVal == '#') {
             alert('url type is needed');
             return false;
         }

         if (urlVal == "") {
             alert('url is needed');
             return false;
         }


         return true;
     }
 </script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dbugstation\tv-chanel\resources\views/layouts/products/edit.blade.php ENDPATH**/ ?>