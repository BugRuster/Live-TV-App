<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Url_type extends Model
{

    protected $guarded = [];
}
