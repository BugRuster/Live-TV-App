<?php

namespace App\Http\Traits;

use App\Brand;

trait BrandsTrait
{
    public function brandsAll()
    {
        // Get all the brands from the Brands Table.

    }
}
