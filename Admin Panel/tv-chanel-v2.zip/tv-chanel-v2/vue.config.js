module.exports = {
  publicPath: './'
}